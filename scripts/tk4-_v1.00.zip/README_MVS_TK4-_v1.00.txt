
The MVS 3.8j Tur(n)key 4- System -- Version 1.00
================================================

Please see folder doc of this distribution for full documentation.

-------------
Juergen Winkelmann, winkelmann@id.ethz.ch, November 27, 2013
